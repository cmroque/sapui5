sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";

      // return Controller.extend("testproject.testproject.controller.App", {
      // });
  
      return BaseController.extend("testproject.testproject.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  